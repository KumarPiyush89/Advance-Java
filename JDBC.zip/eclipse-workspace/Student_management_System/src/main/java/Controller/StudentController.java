package Controller;

import java.util.List;
import java.util.Scanner;

import Model.dao.StudentDao;
import Model.dto.Student;

public class StudentController {
	Scanner sc = new Scanner (System.in);
	Student stu = new Student();
	StudentDao sDao = new StudentDao();
	List<Student> students;
	public  boolean insertStudent() {
		System.out.println("Insert Student");
		System.out.println("Enter Student ID");
		int id = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter Student Name");
		String name = sc.nextLine();
		
		System.out.println("Enter Age");
		int age = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter Aggregate Percentage");
		double aggPercentage = sc.nextDouble();
		sc.nextLine();
		
		System.out.println("Enter Phone");
		long phone = sc.nextLong();
		sc.nextLine();
		
		System.out.println("Enter Collage Name");
		String collageName = sc.nextLine();
		
//		SET ALL FIELD VALUE
		stu.setId(id);
		stu.setName(name);
		stu.setAge(age);
		stu.setAggPercentage(aggPercentage);
		stu.setPhone(phone);
		stu.setCollageName(collageName);
		
		return sDao.insertStudent(stu);		
	}
	
	public boolean removeStudent() {
		System.out.println("Remove Student");
		System.out.println("Enter Student ID");
		int id = sc.nextInt();
		stu.setId(id);
		
		return sDao.removeStudent(stu);
	}
	
	
	public Student viewStudent() {
		System.out.println("View one Student");
		System.out.println("Enter Id");
		int id = sc.nextInt();
		sc.nextLine();
		return sDao.viewStudent(id);
	}
	
	public List<Student> viewAllStudent(){
		return sDao.viewAllStudent();
	}
	
	public boolean updateStudent() {
		System.out.println("Enter Id");
		int id = sc.nextInt();
		stu = sDao.viewStudent(id);
		if(stu != null) {
			System.out.println("Enter new Name OtherWIse press Enter");
			String name = sc.nextLine();
			System.out.println("Enter Age OtherWise Press Enter");
			String age = sc.nextLine();
			System.out.println("Enter AggPercentage OtherWise Press Enter");
			String aggPercentage = sc.nextLine();
			System.out.println("Enter Phone number OtherWise Press Enter");
			String phone = sc.nextLine();
			System.out.println("Enter CollageName Other wise Press Enter");
			String collageName = sc.nextLine();
			
			if(!name.isEmpty()) {
				stu.setName(name);
			}
			
			if(!age.isEmpty()) {
				stu.setAge(Integer.parseInt(age));
			}
			
			if(!aggPercentage.isEmpty()) {
				stu.setAggPercentage(Double.parseDouble(collageName));
			}
			
			if(!phone.isEmpty()) {
				stu.setPhone(Long.parseLong(phone));
			}
			
			if(!collageName.isEmpty()) {
				stu.setCollageName(collageName);
			}
			
//			return sDao.updateStudent(stu);
			
		}
		return false;
			
	}
	
	public static void main(String[] args) {
		StudentController sControl = new StudentController(); 
//		System.out.println(sControl.insertStudent());
//		System.out.println(sControl.removeStudent());
//		System.out.println(sControl.viewStudent());
//		System.out.println(sControl.viewAllStudent());
//		sControl.students = sControl.viewAllStudent();
//		for(Student s : sControl.students) {
//			System.out.println(s);
//		}
		
		
	}
}

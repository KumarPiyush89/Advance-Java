package Model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.dto.Student;

public class StudentDao {
	String url = "jdbc:postgresql://localhost:5432/Student_management_System";
	String user = "postgres";
	String password = "root";
	Connection con;
	Statement stm;
	PreparedStatement ps;
	ResultSet rs;
	List<Student> student = new ArrayList<Student>();
	
	
	{
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url,user,password);
			stm = con.createStatement();
			System.out.println("Connection Stablish");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	public boolean insertStudent(Student stu) {
		String query = "insert into student values(?,?,?,?,?,?)";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,stu.getId());
			ps.setString(2,stu.getName() );
			ps.setInt(3,stu.getAge());
			ps.setDouble(4,stu.getAggPercentage());
			ps.setLong(5,stu.getPhone());
			ps.setString(6,stu.getCollageName());
			
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
	public boolean removeStudent(Student stu) {
		String query = "delete from student where id =?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,stu.getId());
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Student viewStudent(int id) {
		String query ="select * from student where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,id);
			rs = ps.executeQuery();
			if(rs.next()) {
				return new Student(rs.getInt(id),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getLong(5),rs.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Student> viewAllStudent(){
		String query="select * from student";
		try {
			rs = stm.executeQuery(query);
			if(rs.next()) {
				student.clear();
//				System.out.println("empid\tempName\tempSalary\tempPhone\tempPassword");
				System.out.println("====================================================================");
				do{
					student.add(new Student(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getLong(5),rs.getString(6)));
				}
				while(rs.next());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return student;
	}
}

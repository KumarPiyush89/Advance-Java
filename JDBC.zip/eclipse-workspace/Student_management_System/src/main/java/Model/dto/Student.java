package Model.dto;

public class Student {
	private int id;
	private String name;
	private int age;
	private double aggPercentage;
	private long phone;
	private String collageName;
	
	public Student() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getAggPercentage() {
		return aggPercentage;
	}

	public void setAggPercentage(double aggPercentage) {
		this.aggPercentage = aggPercentage;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public String getCollageName() {
		return collageName;
	}

	public void setCollageName(String collageName) {
//		collageName = collageName;
		this.collageName=collageName;
		}
	
	public Student(int id, String name, int age, double aggPercentage, long phone, String collageName) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.aggPercentage = aggPercentage;
		this.phone = phone;
		this.collageName = collageName;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", aggPercentage=" + aggPercentage + ", phone="
				+ phone + ", CollageName=" + collageName + "]";
	}
	
	
}

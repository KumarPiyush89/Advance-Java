package Batch_Execution;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class BatchExecutionDemo {
	public static void main(String[] args) {

//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Step 3 : Create the statement Object
//			Statement stm = con.createStatement();
//			String query1 = "insert into employee values (104,'Vinay',40000)";
//			String query2 = "update employee set salary =300000 where id = 104";
//			String query3 = "delete from employee where id = 104";
//			
//			stm.addBatch(query1);
//			stm.addBatch(query2);
//			stm.addBatch(query3);
//			
//			int [] result = stm.executeBatch();
//			
//			for(int i : result) {
//				System.out.println(i);
//			}
			
			
			String query = "insert into employee values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, 106);
			ps.setString(2, "Neha");
			ps.setDouble(3,100000);
			ps.addBatch();
			ps.setInt(1, 107);
			ps.setString(2,"Puunam");
			ps.setDouble(3, 0);
			ps.addBatch();
			
			int[] result= ps.executeBatch();
			for(int i : result) {
				System.out.println(i);
			}
			
			
			
			
			
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}

package jdbc_steps;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.postgresql.Driver;
import java.sql.Connection;
import java.sql.Statement;
public class jdbcSteps {
	public static void main(String[] args) {
//			steps 1  register
//		Driver driver = new Driver();
//		try {
//			DriverManager.registerDriver(driver);
//			System.out.println("Driver Register");
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Step 3 : Create the statement object
			Statement stm = con.createStatement();
			System.out.println(stm);
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
}

package TransactionManagment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Transactio_Managment_Demo {
	public static void main(String[] args) {

//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
			
//			Step 3 : Create the statement Object
			Statement stm = con.createStatement();
			con.setAutoCommit(false);
			
			String query1 = "insert into employee values (101,'Shree',1000)";
			String query2 = "update employee set salary = 1000 where id = 102";
			String query3 = "delete from employee where id = 102";
			
			int result1 = stm.executeUpdate(query1);
			int result2 = stm.executeUpdate(query2);
			int result3 = stm.executeUpdate(query3);
			
			
			if(result1 > 0 && result2 > 0 &&result3 > 0 )
			{
				con.commit();
				System.out.println("Queries are insertes Successfully");
			}
			else
			{
				con.rollback();
				System.out.println("Queries Are not inserted");
			}
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}

package TransactionManagment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//import java.sql.Savepoint;
import java.sql.Statement;

public class Save_Point_Demo {
	public static void main(String[] args) {

//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Step 3 : Create the statement object
			con.setAutoCommit(false);
			Statement stm = con.createStatement();
			String query1 = "insert into employee values(112,'Alok',23000)";
			String query2 = "insert into employee values(113,'Subham',25000)";
			String query3 = "insert into employee values(114,'Saurabh',30000)";
			
			int r1 = stm.executeUpdate(query1);
//			Savepoint s1 = con.setSavepoint();
			int r2 = stm.executeUpdate(query2);
			int r3 = stm.executeUpdate(query3);
			
//			con.rollback(s1); 
//			con.rollback(s1); this method is store the data in database 
			con.rollback();
			con.commit();
			System.out.println(r1);
			System.out.println(r2);
			System.out.println(r3);
			
			con.commit();
			
			con.close();			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	
	}
}

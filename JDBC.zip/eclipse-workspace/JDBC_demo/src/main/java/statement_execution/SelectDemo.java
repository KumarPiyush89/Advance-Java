package statement_execution;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class SelectDemo {
	public static void main(String[] args) {
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Step 3 : Create the statement object
			Statement stm = con.createStatement();
			System.out.println(stm);
			
//			Step 4 : Executing the DQL Statement
//			String query ="select * from employee";
//			boolean b = stm.execute(query);
//			System.out.println(b);
//			
//			ResultSet rs = stm.getResultSet();
//			
//			while( rs.next()) {
////				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3));
//				System.out.println(rs.getInt("id")+" "+rs.getString("name")+" "+rs.getDouble("salary"));
//			}
//			
			String query = "select * from employee";
			ResultSet rs = stm.executeQuery(query);
			while(rs.next()) {
				System.out.println(rs.getInt("id")+" "+rs.getString("name")+" "+rs.getDouble("salary"));
			}
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package statement_execution;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class insertDemo {
	public static void main(String[] args) {

//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Step 3 : Create the statement object
			Statement stm = con.createStatement();
			System.out.println(stm);
			
//			Step 4 : Executing the statement(DML)
//			insert query
			
//			String query = "insert into employee values(104,'piyush',500000)";
//			System.out.println(stm.execute(query));
			
//			insert Query using executeUpdate();
//			String query1 ="insert into employee values(105,'piyush',500000)";
//			String query1 ="delete from  employee where id = 102";
//			String query1 ="update employee set name = 'Ankit' where id = 102";
			String query1 ="insert into employee values(102,'Kumar',700000)";
			int result = stm.executeUpdate(query1);
			if(result > 0)
			{
				System.out.println("Data Inserted SuccessFully");
			}
			else
			{
				System.out.println("Failed to insert Data");
			}
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}
}

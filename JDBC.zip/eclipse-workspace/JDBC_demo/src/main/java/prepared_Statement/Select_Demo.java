package prepared_Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Select_Demo {
	public static void main(String[] args) {
//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Executing the prepared Statement DQL(select)
			String query = "select * from employee where id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, 101);
			boolean b = ps.execute();
			ResultSet rs = ps.getResultSet();
			while(rs.next()) {
				System.out.println(rs.getInt("id")+" "+rs.getString(2)+" "+rs.getDouble(3));
			}
			

			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}

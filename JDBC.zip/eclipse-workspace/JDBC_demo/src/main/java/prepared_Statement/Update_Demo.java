package prepared_Statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Update_Demo {
	public static void main(String[] args) {

//		Load the driver
		try {
//			Step 1: Load The Driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Loaded");
			
//			Step 2:Estiblisg Connection
			String url ="jdbc:postgresql://localhost:5432/company";
			String user = "postgres";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			System.out.println("Connection Establish");
			
//			Step 3 : Create the PreparedStatement
//			insert
			String query ="update employee set name = 'Ankit' where id = 104";
			PreparedStatement ps = con.prepareStatement(query);
//			ps.setInt(1, 103);
//			ps.setString(2, "Kumar");
//			ps.setDouble(3,600000);
			
//			Using execute()
			boolean b = ps.execute();
			System.out.println(b);
			
//			using executeupdate()
//			ps.setInt(1, 104);
//			ps.setString(2,"Amit");
//			ps.setDouble(3,400000);
			
			int result = ps.executeUpdate();
			if(result > 0) {
				System.out.println("Insert successfully");
			}
			else
			{
				System.out.println("Sorry!!");
			}
			
			
			
			
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
}

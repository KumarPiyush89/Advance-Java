package View;

import java.util.Scanner;

import Controller.EmployeeController;

public class Run {
	
	static {
		System.out.println("=======WELCOME TO EMPLOYEE MANAGMENT SYSTEM========");
		
	}
	
	static Scanner userInput = new Scanner(System.in);
	static EmployeeController eControl = new EmployeeController();
	public static void main(String[] args) {
		Run run = new Run();
		boolean lcondition = true;
		while(lcondition) {
		System.out.println("1. Admin");
		System.out.println("2. Employee Login");
		System.out.println("3. Exit");
		System.out.println("Enter Choice");
		int lChoice = run.userInput.nextInt() ;
		run.userInput.nextLine();
		
		switch(lChoice) {
		
		case 1:{
			boolean acondition = true;
			while(acondition) {
				System.out.println("");
				System.out.println("Have you do any operation (Y/N)");
				char op = userInput.next().charAt(0);
				if(op == 'Y' || op == 'y')
				{
					if(run.eControl.loginValidate())
					{
						System.out.println("1: Insert Employee");
						System.out.println("2: Remove Employe");
						System.out.println("3: View Employee");
						System.out.println("4: View All Employee");
						System.out.println("5: Update Employee");
						System.out.println("6: Exit");
						System.out.println("Enter The Choice");
						int aChoice = run.userInput.nextInt();
						run.userInput.nextLine();
						switch(aChoice) {
						case 6:{
							acondition = false;
							break;
						}
						
						case 1:{
							if(run.eControl.insertEmployee())
							{
								System.out.println("Employee Record Inserted SuccessFully");
								break;
							}
							else
							{
								System.out.println("Failed!! to insert record");
								break;
							}
						}
						
						case 2:{
							if(run.eControl.removeEmployee())
							{
								System.out.println("Employee Remove Successfully");
								break;
							}
							else
							{
								System.out.println("Sorry!! failed to insert Record");
							}
						}
						
						case 3:{							
								System.out.println("Here all the employee Data");
								System.out.print(" You have to details");
								System.out.println(eControl.viewEmployee());
								break;
						}
						
						case 4:{
								System.out.println("Here all the employee Data");
								System.out.println(eControl.viewAllEmployee());
								break;
						}
						
						case 5:{
							if(run.eControl.updateEmloyee()) {
								System.out.println("Data is Updated");
								break;
							}
							else
							{
								System.out.println("Sorry!! Data is Not Updated");
								break;
							}
							
						}
						
						}
					}
				}
				else if(op == 'N' || op == 'n')
				{
					System.out.println("You didn't want to perform any operations");
					
					System.out.println("Thank You");
					acondition = false;
					
				}
			}
			break;
		}
		
		
		
		
		case 2:{
			System.out.println("Employee Login");
			break;
		}
		
		case 3:{
			lcondition = false;
			break;
		}
		}
		
		
		System.out.println("===Thank You===");
		}
	}
}

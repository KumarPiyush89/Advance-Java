package Controller;

import java.util.List;
import java.util.Scanner;

import Model.dao.EmployeeDao;
import Model.dto.Employee;

public class EmployeeController {
	Scanner userInput = new Scanner(System.in);
	Employee emp = new Employee();
	EmployeeDao eDao = new EmployeeDao();
	List<Employee> employees;
	
	public boolean loginValidate() {
		System.out.println("Enter The user Id");
		int id = userInput.nextInt();
		userInput.nextLine();
		System.out.println("Enter Password");
		String password = userInput.nextLine();
		emp.setId(id);
		emp.setPassword(password);
		
		return eDao.loginValidate(emp);
	}
	
	public boolean insertEmployee() {
		System.out.println("Enter the employee id");
		int id = userInput.nextInt();
		userInput.nextLine();
		
		System.out.println("Enter User Name");
		String name = userInput.nextLine();
		
		System.out.println("Enter User Salary");
		double salary = userInput.nextDouble();
		userInput.nextLine();
		
		System.out.println("Enter Phone");
		long phone = userInput.nextLong();
		userInput.nextLine();
		
		System.out.println("Enter Password");
		String password =userInput.nextLine();
		
		emp.setId(id);
		emp.setName(name);
		emp.setSalary(salary);
		emp.setPhone(phone);
		emp.setPassword(password);
		
		return eDao.insertEmployee(emp);
		
	}
	
	public boolean removeEmployee() {
		System.out.println("Enter Employee id");
		int id = userInput.nextInt();
		userInput.nextLine();
		
		emp.setId(id);
		return eDao.removeEmployee(id);
	} //EDF removeEmployee
	
	public Employee viewEmployee() {
		System.out.println("Enter Id");
		int id = userInput.nextInt();
		userInput.nextLine();
		
//		emp.setId(id);
		return eDao.viewEmployee(id);
	}
	
	public List<Employee> viewAllEmployee(){
		return eDao.viewAllEmployee();
	}
	
	
	public boolean updateEmloyee() {
		System.out.println("Enter id");
		int id = userInput.nextInt();
		userInput.nextLine();
		emp = eDao.viewEmployee(id);
		if(emp != null) {
			System.out.println(emp);
			System.out.println("Enter The New Name OtherWise Press Enter");
			String name = userInput.nextLine();
			System.out.println("Enter Salary OtherWise Press Enter");
			String salary = userInput.nextLine();
			System.out.println("Enter phone OtherWise Press Enter");
			String phone = userInput.nextLine();
			System.out.println("Enter password OtherWise Press Enter");
			String password = userInput.nextLine();

			if(!name.isEmpty()) {
				emp.setName(name);
			}
			
			if(!salary.isEmpty()) {
				emp.setSalary(Double.parseDouble(salary));
			}
			
			if(!phone.isEmpty()) {
				emp.setPhone(Long.parseLong(phone));
			}
			
			if(!password.isEmpty()) {
				emp.setPassword(password);
			}
			
			return eDao.updateEmloyee(emp);
		}
		return false;
	}
	
	
	
	
	public static void main(String[] args) {
		EmployeeController eControl = new EmployeeController();
//		System.out.println(eControl.loginValidate());
//		System.out.println(eControl.insertEmployee());
//		System.out.println(eControl.removeEmployee());
//		System.out.println(eControl.viewEmployee());
//		System.out.println(eControl.viewAllEmployee());
//		System.out.println("\n");
		
//		eControl.employees = eControl.viewAllEmployee();
//		for(Employee e : eControl.employees) {
//			System.out.println(e);
//		}
		
		
//		System.out.println(eControl.updateEmloyee());
	}
	
}

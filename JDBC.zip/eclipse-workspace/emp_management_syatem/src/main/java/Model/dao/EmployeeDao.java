package Model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.dto.Employee;

public class EmployeeDao {
	String url = "jdbc:postgresql://localhost:5432/emp_management_system";
	String user = "postgres";
	String password = "root";
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	Statement stm;
	List<Employee> employees = new ArrayList<Employee>();
	
	{ 	//non static initializer
		
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url,user,password);
			stm = con.createStatement();
			System.out.println("Connection Establish");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}// EDF non static block
	
	public boolean loginValidate(Employee emp) {
		String query = "select password from employee where id =? ";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,emp.getId());
			rs = ps.executeQuery();
			if(rs.next())
			{
				if(rs.getString(1).equals(emp.getPassword())) {
					return true;
				}
				else{
					return false;
				}
			}
			else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}	// EDF loginValidate() method
	
	public boolean insertEmployee(Employee emp) {
		String query = "insert into employee values(?,?,?,?,?)";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,emp.getId());
			ps.setString(2,emp.getName());
			ps.setDouble(3,emp.getSalary());
			ps.setLong(4,emp.getPhone());
			ps.setString(5,emp.getPassword());
			
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
	public boolean removeEmployee(int id) {
		String query = "delete from employee where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, id);
			if(ps.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	} //EDF removeEmployee
	
	public Employee viewEmployee(int id) {
		String query = "select * from employee where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
//				return new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getLong(4),rs.getString(5));
				return new Employee(rs.getInt(id),rs.getString(2),rs.getDouble(3),rs.getLong(4),rs.getString(5));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	} // EDF viewEmployee
	
	public boolean updateEmloyee(Employee emp) {
		String query ="update employee set name = ?, salary = ? , phone = ?, password = ?  where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setString(1, emp.getName());
			ps.setDouble(2,emp.getSalary());
			ps.setLong(3, emp.getPhone());
			ps.setString(4,emp.getPassword());
			ps.setInt(5,emp.getId());
			if(ps.executeUpdate() > 0) {
				return true;
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<Employee> viewAllEmployee(){
		String query = "select * from employee";
		try {
			rs = stm.executeQuery(query);
			if(rs.next()) {
				employees.clear();
				System.out.println("empid\tempName\tempSalary\tempPhone\tempPassword");
				System.out.println("====================================================================");
				do{
					employees.add(new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getLong(4),rs.getString(5)+"\n"));
				}
				while(rs.next());
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employees;
		
	}
	

}

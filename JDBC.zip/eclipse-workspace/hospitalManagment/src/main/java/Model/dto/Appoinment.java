package Model.dto;

public class Appoinment {
	private int patientId;
	private int doctorId;
	private String appoinmentDate;
	public Appoinment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Appoinment(int patientId, int doctorId, String appoinmentDate) {
		super();
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appoinmentDate = appoinmentDate;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getAppoinmentDate() {
		return appoinmentDate;
	}
	public void setAppoinmentDate(String appoinmentDate) {
		this.appoinmentDate = appoinmentDate;
	}
	@Override
	public String toString() {
		return "Appoinment [patientId=" + patientId + ", doctorId=" + doctorId + ", appoinmentDate=" + appoinmentDate
				+ "]";
	}
	
	
}

package Model.dto;

public class Login {
	private int id;
	private String userid;
	private String pwd;
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(int id,String userid, String pwd) {
		this.id = id;
		this.userid = userid;
		this.pwd = pwd;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "Login [id=" + id + ", userid=" + userid + ", pwd=" + pwd + "]";
	}
	
}

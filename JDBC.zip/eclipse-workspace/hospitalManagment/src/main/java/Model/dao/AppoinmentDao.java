package Model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Model.dto.Doctor;
import Model.dto.Patient;

public class AppoinmentDao {
	String url = "jdbc:postgresql://localhost:5432/hospital_management_system";
	String user = "postgres";
	String password = "root";
	Connection con;
	Statement stm;
	PreparedStatement ps;
	ResultSet rs;
	
	{
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url,user,password);
			stm = con.createStatement();
//			System.out.println("Connection Stablish Doctor ");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
//	public boolean bookAppoinment(Patient pati, Doctor doc) {
//		
//	}
	
}

package Model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Model.dto.Login;



public class LoginDao {
	String url = "jdbc:postgresql://localhost:5432/hospital_management_system";
	String user = "postgres";
	String password = "root";
	Connection con;
	Statement stm;
	PreparedStatement ps;
	ResultSet rs;
	Login log = new Login();
	
	{
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url,user,password);
			stm = con.createStatement();
//			System.out.println("Connection Stablish Doctor ");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	public boolean loginValidate(Login log) {
		String query = "select userid, pwd from login where id=?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,log.getId());
//			ps.setString(2,log.getUserid());
//			ps.setString(3,log.getPwd());
			rs = ps.executeQuery();
			if(rs.next())
			{
//				both comparision 
				if(rs.getString(1).equals(log.getUserid()) || rs.getString(2).equals(log.getPwd())) {
					return true;
//					if(rs.getString(3).equals(log.getPwd()))
//					{
//						System.out.println("Login successfully");
//						return true;
//					}
//					else
//					{
//						System.out.println("UserId Or Password is Wrong");
//						return false;
//					}
					
				}
				else{
					System.out.println("UserId Or Password is Wrong");
					return false;
				}
			}
			else{
				return false;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
		
	}// EDF loginValidate() method
	
	public boolean insertAdmin(Login log) {
		String query = "insert into login values(?,?,?)";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, log.getId());
			ps.setString(2,log.getUserid());
			ps.setString(3,log.getPwd());
			
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return false;
		
	}
	
}
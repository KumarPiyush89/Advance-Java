package Model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.dto.Doctor;


public class DoctorDao {
	String url = "jdbc:postgresql://localhost:5432/hospital_management_system";
	String user = "postgres";
	String password = "root";
	Connection con;
	Statement stm;
	PreparedStatement ps;
	ResultSet rs;
	List<Doctor> doctor = new ArrayList<Doctor>();
	
	{
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url,user,password);
			stm = con.createStatement();
//			System.out.println("Connection Stablish Doctor ");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public boolean insertDoctor(Doctor doct) {
		String query = "insert into doctors values(?,?,?)";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,doct.getId());
			ps.setString(2,doct.getName());
			ps.setString(3,doct.getSpecialization());
			
						
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	} // end of insert Patient
	
	
	public boolean removeDoctor(Doctor doct) {
		String query = "delete from doctors where id =?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,doct.getId());
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	} // end of patient Remove
	
	public Doctor viewDoctor(int id) {
		String query ="select * from doctors where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,id);
			rs = ps.executeQuery();
			if(rs.next()) {
				return new Doctor(rs.getInt(1),rs.getString(2),rs.getString(3));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	} //end of one  patient view 
	
	
	public List<Doctor> viewAllDoctor(){
		String query="select * from doctors";
		try {
			rs = stm.executeQuery(query);
			if(rs.next()) {
				doctor.clear();
//				System.out.println("====================================================================");
				do{
					doctor.add(new Doctor(rs.getInt(1),rs.getString(2),rs.getString(3)));
				}
				while(rs.next());
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return doctor;
	} //end of view all Patient
	
	
	public boolean updateDoctor(Doctor doc) {
		String query = "update doctors set name = ?,specialization = ? where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setString(1,doc.getName());
			ps.setString(2,doc.getSpecialization());
			ps.setInt(3, doc.getId());
			if(ps.executeUpdate() > 0) {
				return true;
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	
//	public static bookAppoinment() {
//		
//	}
	
	
	
	
	
	public static void main(String[] args) {
//		DoctorDao dao = new DoctorDao();
	}

}

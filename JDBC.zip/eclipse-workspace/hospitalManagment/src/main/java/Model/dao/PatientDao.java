package Model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import Model.dto.Patient;



public class PatientDao {
	String url = "jdbc:postgresql://localhost:5432/hospital_management_system";
	String user = "postgres";
	String password = "root";
	Connection con;
	Statement stm;
	PreparedStatement ps;
	ResultSet rs;
	List<Patient> patient = new ArrayList<Patient>();
	
	{
		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection(url,user,password);
			stm = con.createStatement();
//			System.out.println("Connection Stablish Patients");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	// EDF non static block
	
//	
	
	
	public boolean insertPatient(Patient pati) {
		String query = "insert into patients values(?,?,?,?)";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,pati.getId());
			ps.setString(2,pati.getName());
			ps.setInt(3,pati.getAge());
			ps.setString(4,pati.getGender());
						
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	} // end of insert Patient
	
	
	public boolean removePatient(Patient pati) {
		String query = "delete from patients where id =?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,pati.getId());
			if(ps.executeUpdate() > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	} // end of patient Remove
	
	
	public Patient viewPatient(int id) {
		String query ="select * from patients where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setInt(1,id);
			rs = ps.executeQuery();
			if(rs.next()) {
				return new Patient(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	} //end of one  patient view 
	
	
	
	public List<Patient> viewAllPatient(){
		String query="select * from patients";
		try {
			rs = stm.executeQuery(query);
			if(rs.next()) {
				patient.clear();
				
				do{
					patient.add(new Patient(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4)));
				}
				while(rs.next());
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return patient;
	} //end of view all Patient

	
	public boolean updatePatient(Patient pati) {
		String query ="update patients  set name = ? , age = ?, gender = ?  where id = ?";
		try {
			ps = con.prepareStatement(query);
			ps.setString(1, pati.getName());
			ps.setInt(2,pati.getAge());
			ps.setString(3, pati.getGender());
			ps.setInt(4,pati.getId());
			
			if(ps.executeUpdate() > 0) {
				return true;
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	} // end of updatePatient
	

	
		
	
	
	public static void main(String[] args) {
		PatientDao dao = new PatientDao();
	}
}

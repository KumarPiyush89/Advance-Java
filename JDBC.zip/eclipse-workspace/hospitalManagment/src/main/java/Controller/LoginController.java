package Controller;

import java.util.Scanner;

import Model.dao.LoginDao;
import Model.dto.Login;

public class LoginController {
	
	Scanner userInput = new Scanner(System.in);
	Login log = new Login();
	LoginDao logDao = new LoginDao();
	
	
	public boolean loginValidate()
	{
		System.out.println("Enter Id");
		int id = userInput.nextInt();
		
		System.out.println("Enter userId");
		String userid = userInput.next();
//		userInput.next();
		
		System.out.println("Enter Password");
		String pwd = userInput.next();
		
		log.setId(id);
		log.setUserid(userid);
		log.setPwd(pwd);
		
		return logDao.loginValidate(log);
	}
	
	
	public boolean insertAdmin() {
		System.out.println("Enter id");
		int id = userInput.nextInt();
		userInput.nextLine();
		System.out.println("Enter UserId");
		String userid = userInput.nextLine();
		System.out.println("Enter Password");
		String pwd = userInput.nextLine();
		
		log.setId(id);
		log.setUserid(userid);
		log.setPwd(pwd);
		
		return logDao.insertAdmin(log);
	}// end of insertAdmin
	
	
	
	
	
	
	public static void main(String[] args) {
		LoginController lController = new LoginController();
//		System.out.println(lController.insertAdmin());
		System.out.println(lController.loginValidate());
	}
	

}

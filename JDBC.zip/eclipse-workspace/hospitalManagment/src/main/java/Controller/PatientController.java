package Controller;

import java.util.List;
import java.util.Scanner;

import Model.dao.PatientDao;
import Model.dto.Patient;



public class PatientController {

		Scanner userInput = new Scanner(System.in);
		Patient pati = new Patient();
		PatientDao eDao = new PatientDao();
		List<Patient> patient;
	
		public boolean insertPatient() {
			System.out.println("Enter the Patient id");
			int id = userInput.nextInt();
			userInput.nextLine();
			
			System.out.println("Enter Patient Name");
			String name = userInput.nextLine();
			
			System.out.println("Enter Patient Age");
			int age = userInput.nextInt();
			userInput.nextLine();
			
			System.out.println("Enter Patient Gender");
			String gender = userInput.nextLine();
			
			pati.setId(id);
			pati.setName(name);
			pati.setAge(age);
			pati.setGender(gender);
			
			
			return eDao.insertPatient(pati);
			
		} // end of insertPatient
		
		public boolean removePatient() {
			System.out.println("Enter Patient ID");
			int id = userInput.nextInt();
			pati.setId(id);
			
			return eDao.removePatient(pati);
		} // end of remove Patient
		
		public Patient viewPatient() {
			System.out.println("View one Patient");
			System.out.println("Enter Id");
			int id = userInput.nextInt();
			userInput.nextLine();
			return eDao.viewPatient(id);
		} // end of view All Patient
		
		public boolean updatePatient() {
			System.out.println("Enter id");
			int id = userInput.nextInt();
			userInput.nextLine();
			pati = eDao.viewPatient(id);
			if(pati != null) {
				System.out.println(pati);
				System.out.println("Enter The New Name OtherWise Press Enter");
				String name = userInput.nextLine();
				System.out.println("Enter Age OtherWise Press Enter");
				String age = userInput.nextLine();
				System.out.println("Enter Gender OtherWise Press Enter");
				String gender = userInput.nextLine();
				
				if(!name.isEmpty()) {
					pati.setName(name);
				}
				
				if(!age.isEmpty()) {
					pati.setAge(Integer.parseInt(age));
				}
				
			
				if(!gender.isEmpty()) {
					pati.setGender(gender);
				}	
				
				return eDao.updatePatient(pati);
			}
			return false;
		}
		
		
		
		
		public List<Patient> viewAllPatient(){
			System.out.println(" ____________________________________________________________");
			System.err.println("\t\t\tPATIENT");
			System.out.println("| Patient Id | Patient Name | Patient Age  |  Patient gender |");
			System.out.println(" ____________________________________________________________");
			return eDao.viewAllPatient();
		}
		
		public static void main(String[] args) {
			PatientController pController = new PatientController();
//			System.out.println(pController.insertPatient());
//			System.out.println(pController.viewPatient());
//			System.out.println(pController.viewAllPatient());
			System.out.println(pController.updatePatient());
//			System.out.println(pController.viewAllPatient());
		}
}

package Controller;

import java.util.List;
import java.util.Scanner;

import Model.dao.DoctorDao;
import Model.dto.Doctor;
import Model.dto.Patient;


public class DoctorController {
	
	Scanner userInput = new Scanner(System.in);
	Doctor doct = new Doctor();
	DoctorDao eDao = new DoctorDao();
	List<Doctor> doctor;
	
	
	public boolean insertDoctor() {
		System.out.println("Enter the Doctor id");
		int id = userInput.nextInt();
		userInput.nextLine();
		
		System.out.println("Enter Doctor Name");
		String name = userInput.nextLine();
		
		System.out.println("Enter Doctor Specialization");
		String Specialization = userInput.nextLine();
		
		
		doct.setId(id);
		doct.setName(name);
		doct.setSpecialization(Specialization);
		
		
		return eDao.insertDoctor(doct);
		
	} // end of insertPatient
	
	
	public boolean removeDoctor() {
		System.out.println("Remove Doctor");
		System.out.println("Enter Doctor ID");
		int id = userInput.nextInt();
		doct.setId(id);
		
		return eDao.removeDoctor(doct);
	} // end of remove Patient
	
	public Doctor viewDoctor() {
		System.out.println("View one Doctor");
		System.out.println("Enter Id");
		int id = userInput.nextInt();
		userInput.nextLine();
		return eDao.viewDoctor(id);
	} // end of view All Patient
	
	
	public List<Doctor> viewAllDoctor(){
		System.out.println(" ___________________________________________________");
		System.err.println("\t\t\tDOCTOR");
		System.out.println("| Doctor Id | Doctor Name | Doctor Specialization  |");
		System.out.println(" ___________________________________________________");
		return eDao.viewAllDoctor();
		
		
	} // View All Doctor
	
	public boolean updateDoctor() {
		System.out.println("Enter id");
		int id = userInput.nextInt();
//		userInput.nextLine();
		doct = eDao.viewDoctor(id);
		userInput.nextLine();
		if(doct != null) {
			System.out.println(doct);
			System.out.println("Enter new  Name otherwise press enter");
			String name = userInput.nextLine();
			System.out.println("Enter specialization");
			String specialization = userInput.nextLine();
			
			if(!name.isEmpty()) {
				doct.setName(name);
			}
			
			if(!specialization.isEmpty()) {
				doct.setSpecialization(specialization);
			}
			return eDao.updateDoctor(doct);
		}
		return false;
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		DoctorController dController = new DoctorController();
//		System.out.println(dController.insertDoctor());
//		System.out.println(dController.viewDoctor());
//		System.out.println(dController.viewAllDoctor());
//		System.out.println(dController.updateDoctor());
	}

}

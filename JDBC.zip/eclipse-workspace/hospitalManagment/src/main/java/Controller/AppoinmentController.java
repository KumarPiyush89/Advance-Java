package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import Model.dao.AppoinmentDao;
import Model.dto.Appoinment;
import Model.dto.Doctor;
import Model.dto.Patient;

public class AppoinmentController {
//	public boolean bookAppoinment() {
//		Scanner userInput = new Scanner(System.in);
//		Appoinment apon = new Appoinment();
//		AppoinmentDao aDao = new AppoinmentDao();
//		
//		System.out.println("Enter Patient id");
//		int patientid = userInput.nextInt();
//		System.out.println("Enter Doctor id");
//		int doctorid = userInput.nextInt();
//		System.out.println("Enter Appoinment Date");
//		String appoinmentDate = userInput.nextLine();
//		
//		apon.setPatientId(patientid);
//		apon.setDoctorId(doctorid);
//		apon.setAppoinmentDate(appoinmentDate);
//		
////		return aDao.bookAppoinment(apon);
//		
//		
//	} // end of bookAppoinment
	public static void bookAppoinment(Patient patient , Doctor doctor) {
		Scanner userInput = new Scanner(System.in);
		System.out.println("Enter Patient id");
		int patientid = userInput.nextInt();
		System.out.println("Enter Doctor id");
		int doctorid = userInput.nextInt();
		System.out.println("Enter Appoinment Date (yyyy-mm-dd) ");
		String appoinmentdate = userInput.next();
		
		
		if(patient.getId(patientid) && doctor.getId(doctorid)) {
			if(checkDoctor(doctorid,appoinmentdate)) {
				String appoinmentQuery = "Insert into appointments(patient_id,doctor_id,appoinment_date) values(?, ?, ?)";
				try {
					PreparedStatement = Connection
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}else {
				System.out.println("Doctor not available on this date");
			}
		}else {
			System.out.println("Ether Doctor and Patient doesn't Available");
		}
	}
}

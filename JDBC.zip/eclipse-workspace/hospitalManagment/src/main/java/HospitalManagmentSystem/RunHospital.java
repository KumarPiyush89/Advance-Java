package HospitalManagmentSystem;

import java.util.Scanner;

import Controller.DoctorController;
import Controller.LoginController;
import Controller.PatientController;
import Model.dto.Doctor;
import Model.dto.Patient;


public class RunHospital {
	
	
	
	
	
	static {
		System.out.println("=============== WELCOME TO HOSPITAL MANAGEMENT SYSTEM =============== ");
	}
	
	static Scanner userInput = new Scanner(System.in);
	static PatientController pControl = new PatientController();
	static DoctorController dControl = new DoctorController();
	static LoginController lControl = new LoginController();
	public static void main(String[] args) {
		RunHospital run = new RunHospital();
		
//		Management Login
		boolean management = true;
		while(management) {
			System.out.println(" _______________________");
			System.out.println("| 1 . Management Login  |");
			System.out.println("| 2 . User Info         |");
			System.out.println("| 3 . Exit              |");
			System.out.println(" _______________________");
			System.out.println("Your Choice");
			int mChoice = RunHospital.userInput.nextInt();
			switch(mChoice) {
			
//			Start  of management case one
			case 1:{
//				Management information
				System.out.println("_________________________________");
				System.err.println("| Welcome To Management Login\t|");
				System.out.println("_________________________________");
				System.err.println("\t*Login Validation* ");
				boolean all = true;
				while(all) {
					
					if(RunHospital.lControl.loginValidate()) 
					{
						{
							System.out.println("\tLogin Successfully");
						}
					
					System.out.println("Have you do any operation (Y/N)");
					char op = userInput.next().charAt(0);
					if(op == 'Y' || op == 'y')
					{
					
		
							
							System.out.println(" _________________________");
							System.out.println("| 1. Insert Doctor        |");
							System.out.println("| 2. Update Doctor        |");
							System.out.println("| 3. View All Doctor      |");
							System.out.println("| 4. Delete Doctor        |");
							System.out.println("| 5. Update Patient       |");
							System.out.println("| 6. View ALl Patient     |");
							System.out.println("| 7. Delete Patient       |");
							System.out.println("| 8. Exit                 |");
							System.out.println(" _________________________");
							
							System.out.println("Enter Choice ");
							int yChoice = run.userInput.nextInt();
							run.userInput.nextLine();
							
							switch(yChoice) {
							case 1:{
		//							System.out.println(" 1. Insert Doctor");
									System.out.println(dControl.insertDoctor());
									System.out.println("Doctor Inserted Successfully");
									System.err.println("___________________________________________________");
									
								break;
							}
							case 2:{
		//						System.out.println(" 2. Update Doctor");
								System.out.println(dControl.updateDoctor());
								System.out.println("Doctor Updated Successfully");
								System.err.println("___________________________________________________");
								break;
							}
							case 3:{
		//							System.out.println(" 3. View All Doctor");
									System.out.println(dControl.viewAllDoctor());
									System.err.println("___________________________________________________");
								break;
							}
							case 4:{
		//						System.out.println(" 4. Delete Doctor");
								System.out.println(dControl.removeDoctor());
								System.err.println("Doctor Deleted Successfully");
								System.err.println("___________________________________________________");
								break;
							}
							case 5:{
		//						System.out.println(" 5. Update Patient");
								System.out.println(pControl.updatePatient());
								System.err.println("Patient Record Update Successfully");
								System.err.println("___________________________________________________");
								break;
							}
							case 6:{
		//						System.out.println(" 6. View All Patient");
								System.out.println(pControl.viewAllPatient());
								System.err.println("_____________________________________________________________");
								break;
							}
							case 7:{
		//						System.out.println(" 7. Delete Patient");
								System.out.println(pControl.removePatient());
								System.err.println(" Patient Remove Successfully");
								System.err.println("___________________________________________________");
							}
							case 8:{
		//						System.out.println("Exit");
								all = false;
								break;
							}
		
							
							
							}
							
							
					}
					else if(op == 'N' || op == 'n')
					{
						System.out.println("You didn't want to perform any operations");
						
						System.out.println("Thank You");
						all = false;
						
					}
						
					}
					else {
						
					}
					
					
				} //end of while
				
				
					break;
				} // end of management case one
			
//			Start of management case two
			case 2:{
//				user Information
				System.out.println("|-------Welocome to User info--------|");
				System.err.println("\t\t");
				
				boolean all = true;
				while(all) {
					//choice
					System.out.println("");
					System.out.println("Have you do any operation (Y/N)");
					char op = userInput.next().charAt(0);
					if(op == 'Y' || op == 'y')
					{
					
						System.out.println(" 1 . Insert Patient ");
						System.out.println(" 2 . View Patient ");
						System.out.println(" 3 . View Doctor");
						System.out.println(" 4 . Book Appoinment");
						System.out.println(" 5 . Exit ");
						
						System.out.println("Enter Choice ");
						int yChoice = run.userInput.nextInt();
						run.userInput.nextLine();
						
						switch(yChoice) {
						case 1:{
								System.out.println(pControl.insertPatient());
								System.out.println("Patient Inserted Successfully");
							break;
						}
										
						case 2:{
							System.out.println(pControl.viewAllPatient());
							System.out.println("Here All Patient");
							break;
						}
						case 3:{
							System.out.println(dControl.viewAllDoctor());
							System.out.println("Here All Doctor");
							break;
						}
						case 4:{
							System.out.println("Book Apoinment");
							break;
						}
						case 5:{
							all = false;
							break;
						}
						
						}
//						System.out.println("====Thank You====");
					
					}
					else if(op == 'N' || op == 'n')
					{
						System.out.println("You didn't want to perform any operations");
						
						System.out.println("Thank You");
						all = false;
						
					}
					//end choice
				}
				
				break;
			} // end of management case two
			
//			Start of management case three
			case 3:{
//				Exit case three
				management = false;				
				break;
			} // end of management case three
			
			
			}//end of mChoice 
		}
				
//		user 
		
		
	}
	
}

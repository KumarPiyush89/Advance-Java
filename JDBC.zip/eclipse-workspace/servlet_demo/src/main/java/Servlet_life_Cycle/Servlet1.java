package Servlet_life_Cycle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(value="/serv1", loadOnStartup=1)
public class Servlet1 extends HttpServlet{
	
	static {
		System.out.println("This is static block");
	}
	
	@Override
	public void init() throws ServletException {
		System.out.println("This is init() method of servlet 1");
	}
	public Servlet1() {
		System.out.println("This is the constructor of servlet 1");
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("This is doget ()  Method Of servlet 1");
	}
	

}

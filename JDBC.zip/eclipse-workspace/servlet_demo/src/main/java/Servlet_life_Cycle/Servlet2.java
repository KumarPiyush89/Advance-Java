package Servlet_life_Cycle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value="/serv2", loadOnStartup = 2 )
public class Servlet2 extends HttpServlet {
	static {
		System.out.println("This is static block");
	}
	
	@Override
	public void init() throws ServletException {
		System.out.println("This is init() method of servlet 2");
	}
	public Servlet2() {
		System.out.println("This is the constructor of servlet 2");
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("This is doget ()  Method Of servlet 2");
	}
}

package http_Session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(value="/servB4")
public class ServletB4 extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		String name = (String)session.getAttribute("name");
		String password = (String)session.getAttribute("password");
		String email = (String)session.getAttribute("email");
		
		PrintWriter pw = resp.getWriter();
		pw.println(name);
		pw.println(password);
		pw.println(email);
		
	}
}

package http_Session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(value="/servA4")
public class ServletA4 extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		String email = req.getParameter("email");
		PrintWriter pw = resp.getWriter();
		
//		Login validation
		
		if(name.equals("Piyush") && password.equals("piy123")) {
			HttpSession session = req.getSession();
			session.setAttribute("name", name);
			session.setAttribute("password", password);
			session.setAttribute("email", email);
			
			pw.println("<a href='servB4'>View Data</a>");
			pw.println("<a href='logout'>Logout</a>");
		}
		else
		{
			pw.println("Login Failed");
		}
	}
}

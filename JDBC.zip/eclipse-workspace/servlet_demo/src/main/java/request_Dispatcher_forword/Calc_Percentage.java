package request_Dispatcher_forword;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet (value="/calc_perc")
public class Calc_Percentage extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		double s1 = Double.parseDouble(req.getParameter("sub1"));
		double s2 = Double.parseDouble(req.getParameter("sub2"));
		double s3 = Double.parseDouble(req.getParameter("sub3"));
		
		double percentage = ((s1+s2+s3)/300)*100;
		req.setAttribute("perc",percentage);
		
		RequestDispatcher rd = req.getRequestDispatcher("perc");
		rd.forward(req, resp);
	}
}

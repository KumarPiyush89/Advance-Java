package request_Dispatcher_forword;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(value="/perc")
public class Disp_percentage extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		double percentage = (Double)req.getAttribute("perc");
		
		PrintWriter pw = resp.getWriter();
		pw.println("<html><body>");
		pw.println("<h2> Name : " +name+"</h2>");
		if(percentage > 35.0)
		{
			pw.println("<h2> Result : Passed </h2>");
		}
		else
		{
			pw.println("<h2> Result : Failed </h2>");
		}
		pw.println("</html></body>");
		
	}
}

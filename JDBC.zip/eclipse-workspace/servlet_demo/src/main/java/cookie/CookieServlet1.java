package cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(value="/serv_cookie1")
public class CookieServlet1 extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("uname");
		String password = req.getParameter("Password");
		String email = req.getParameter("email");
		
		Cookie c_name = new Cookie("name", name);
		Cookie c_password = new Cookie("Password", password);
		Cookie c_email = new Cookie("email", email);
		
		c_name.setMaxAge(60);	
		c_name.setValue("Kumar");
		
		resp.addCookie(c_name);
		resp.addCookie(c_password);
		resp.addCookie(c_email);
		
		PrintWriter pw = resp.getWriter();
		pw.println("<a href='serv_cookie2'>Go to CookieServlet2</a>");
	}
}

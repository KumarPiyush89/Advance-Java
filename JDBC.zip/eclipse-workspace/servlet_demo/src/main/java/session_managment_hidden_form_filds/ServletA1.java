package session_managment_hidden_form_filds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(value="/servA1")
public class ServletA1 extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("uname");
		String age = req.getParameter("age");
		
		resp.setContentType("text/html");
		PrintWriter pw = resp.getWriter();
		pw.println("<html><body>");
		pw.println("<form action='servB1' method='post'>");
		pw.println("Email : <input type='text' name='email'  >");
		pw.println("Phone : <input type='tel' name='phone'  >");
		pw.println("<input type='hidden' name='name' value='"+name+"' >");
		pw.println("<input type='hidden' name='age' value='"+age+"' >");
		pw.println("<input type='submit'>");
		pw.println("</form>");
		pw.println("</body></html>");
	}
}

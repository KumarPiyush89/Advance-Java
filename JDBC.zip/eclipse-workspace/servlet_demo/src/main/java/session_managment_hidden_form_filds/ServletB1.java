package session_managment_hidden_form_filds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet (value="/servB1")
public class ServletB1 extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name =req.getParameter("name");
		String age =req.getParameter("age");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		
		PrintWriter pw = resp.getWriter();
		pw.println("name :-"+name);
		pw.println("Age :-"+age);
		pw.print("email : "+email);
		pw.println("Phone :-"+phone);
		
	}
}

package generic_servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Student_servlet extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		String name = req.getParameter("name");
		int age =Integer.parseInt(req.getParameter("age"));
		long phone = Long.parseLong(req.getParameter("phone"));
		String dob = req.getParameter("dob");
		String gender = req.getParameter("gender");
		String[] skills = req.getParameterValues("skills");
		
		PrintWriter pw = res.getWriter();
		pw.println("<html><body>");
		pw.print("<h1> Name :"+name);
		pw.print("<h1> Age :"+age);
		pw.print("<h1> Phone :"+phone);
		pw.print("<h1> DOB :"+dob);
		pw.print("<h1> Gender :"+gender);
		pw.println("<ul>");
		for(String s : skills) {
			pw.println("<li>");
			pw.println(s);
			pw.println("</li>");
		}
		pw.println("/<ul>");
		pw.println("</body></html>");
		
		
	}
	
}

package ServletClass1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Servlet_first extends GenericServlet{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		System.out.println("This Is Second Servlet");
		PrintWriter pw = res.getWriter();
		pw.write("<html><body>");
		pw.print("<h1>This is Second servlet</h1>");
		pw.println("<h2>This is Second Servlet</h2>");
		pw.print("<h1>Hello piyush</h1>");
		pw.write("</body></html>");
		
	}

}

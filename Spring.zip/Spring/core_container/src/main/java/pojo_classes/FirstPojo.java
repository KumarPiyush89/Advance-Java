package pojo_classes;

public class FirstPojo {
	public void message() {
		System.out.println("Hello Spring");
	}

}

package config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "pojo_classes")
public class Config {
	
}

package pojo_classes;

public class DatabaseConfig {

	public String url;
	public String user;
	public String password;
	public DatabaseConfig(String url, String user, String password) {
		super();
		this.url = url;
		this.user = user;
		this.password = password;
	}
	
	
}

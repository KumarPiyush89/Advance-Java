package run;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pojo_classes.DatabaseConfig;

public class Run {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		DatabaseConfig dbConfig = (DatabaseConfig)context.getBean("db");
		
		System.out.println(dbConfig.url);
		System.out.println(dbConfig.user);
		System.out.println(dbConfig.password);

}
}
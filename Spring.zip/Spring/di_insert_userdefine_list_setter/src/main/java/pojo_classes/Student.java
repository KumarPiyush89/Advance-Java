package pojo_classes;

import java.util.List;

public class Student {

	private List<College> college;

	public List<College> getCollege() {
		return college;
	}

	public void setCollege(List<College> college) {
		this.college = college;
	}
	
	
}

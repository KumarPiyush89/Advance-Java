package pojo_classes;

//third party class , we cannot provide @Component annotation
public class Angular implements FrontEnd {
	public void buildFrontEnd() {
		System.out.println("FrontEnd build using angular technology");
	}
}

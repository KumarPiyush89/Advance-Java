package pojo_classes;

public interface FrontEnd {
	public void buildFrontEnd();
}

package pojo_classes;


public class React implements FrontEnd {
	public void buildFrontEnd() {
		System.out.println("Build frontend using react technology");
	}
}

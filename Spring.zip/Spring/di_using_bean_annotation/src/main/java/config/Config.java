package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;

import pojo_classes.Angular;
import pojo_classes.React;

//@Configuration is not need in the recent spring version
//@Configuration 
@ComponentScan(basePackages = "pojo_classes")
public class Config {
	@Bean
	public Angular getAngular() {
		return new Angular();
	}
	
	@Primary
	@Bean
	public React getReact() {
		return new React();
	}
}

package pojo_classes;

import org.springframework.stereotype.Component;

@Component("vehicle")
public class Vehicle {
	public void myVehicle() {
		System.out.println("My Vehicle");
	}
}

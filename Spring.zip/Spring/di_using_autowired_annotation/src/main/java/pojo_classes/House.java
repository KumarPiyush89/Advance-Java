package pojo_classes;

import org.springframework.stereotype.Component;

@Component("house")
public class House {
	public void myHouse() {
		System.out.println("My House");
	}
}

package pojo_classes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("person")
public class Person {
	
	@Autowired
	Mobile mobile;
	
	House house;
	
	private Vehicle vehicle ;
	
	public Vehicle getVehicle() {
		return vehicle;
	}

	
	@Autowired
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}


	public Person(@Autowired House house) {
		this.house = house;
	}
	
	public void mVehicle() {
		vehicle.myVehicle();
	}
	
	public void house() {
		house.myHouse();
	}
	
	public void call() {
		System.out.println("Person is calling");
		mobile.ring();
	}
}

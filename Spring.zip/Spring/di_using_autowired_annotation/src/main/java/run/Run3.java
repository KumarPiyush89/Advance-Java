package run;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pojo_classes.Person;
import pojo_classes.Vehicle;

public class Run3 {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		Person p = (Person)context.getBean("person");
		p.mVehicle();
		
	}
}

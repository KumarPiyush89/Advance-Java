package pojo_classes;

import java.util.List;

public class Student {

	public List<Subject> subjects;

	public Student(List<Subject> subjects) {
		super();
		this.subjects = subjects;
	}
	
}

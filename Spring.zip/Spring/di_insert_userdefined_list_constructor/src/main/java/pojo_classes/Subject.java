package pojo_classes;

public class Subject {
	
	public String name;

	public Subject(String name) {
		super();
		this.name = name;
	}
	

}

package pojo_classes;

public class Item {
	
	public String name;
	public double price;
	public Item(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}
	

}

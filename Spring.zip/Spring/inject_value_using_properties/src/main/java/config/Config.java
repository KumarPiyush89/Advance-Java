package config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

@PropertySource("data.properties")
@ComponentScan(basePackages = "pojo_classes")

public class Config {
	
}

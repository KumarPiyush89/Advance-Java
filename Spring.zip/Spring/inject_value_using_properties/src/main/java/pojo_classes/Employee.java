package pojo_classes;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {
	@Value("${id}")
	int id;
	
	@Value("${name}")
	String name;
	
	@Value("${age}")
	int age;
	
	@Value("${phone}")
	long phone;

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", phone=" + phone + "]";
	}
	
}

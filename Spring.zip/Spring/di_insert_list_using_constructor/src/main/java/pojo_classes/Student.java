package pojo_classes;

import java.util.List;

public class Student {
	public List<String> subjects;

	public Student(List<String> subjects) {
		super();
		this.subjects = subjects;
	}
	

}

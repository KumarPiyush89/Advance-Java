package run;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import config.Config;
import pojo_classes.Employee;

public class Run2 {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		Employee employee =(Employee)context.getBean("emp");
		System.out.println(employee);
		employee.name = "Vishal";
		Employee employee2 = (Employee)context.getBean("emp"); // Same  Object is returned by Spring container
		System.out.println(employee2);
	}
}

package pojo_classes;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("emp")
@Scope("singleton")
public class Employee {
	@Value("Piyush")
	public String name;
	
	@Override
	public String toString() {
		return "Person[name = " +name +"]";
	}
}

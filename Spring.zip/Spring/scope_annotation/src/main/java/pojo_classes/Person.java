package pojo_classes;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("per")
@Scope("prototype")
public class Person {
	@Value("Virat")
	public String name;
	
	@Override
	public String toString() {
		return "Person[name = " +name +"]";
	}
}

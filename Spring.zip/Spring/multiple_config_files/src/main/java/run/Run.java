package run;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pojo_classes.Databases;
import pojo_classes.Frontend;
import pojo_classes.Security;

public class Run {
	public static void main(String[] args) {
		ApplicationContext dbcontext = new ClassPathXmlApplicationContext("dbconfig.xml");
		ApplicationContext webcontext = new ClassPathXmlApplicationContext("webconfig.xml");
		ApplicationContext securitycontext = new ClassPathXmlApplicationContext("securityconfig.xml");
		
		Databases db = (Databases)dbcontext.getBean("db");
		Frontend web = (Frontend)webcontext.getBean("web");
		Security security = (Security)securitycontext.getBean("security");
		
		db.display();
		web.display();
		security.display();
		
	}
}	

package pojo_classes;

public class Security {
	public void display() {
		System.out.println("This is a Security Class");
	}
}

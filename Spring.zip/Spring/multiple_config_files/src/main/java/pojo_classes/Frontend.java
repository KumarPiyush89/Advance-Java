package pojo_classes;

public class Frontend {
	public void display() {
		System.out.println("This is a frontend Class");		
	}
}

package pojo_classes;

public class Databases {
	public void display() {
		System.out.println("This is a DB class");
	}
}

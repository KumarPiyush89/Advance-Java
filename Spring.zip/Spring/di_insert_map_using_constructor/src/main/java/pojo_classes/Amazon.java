package pojo_classes;

public class Amazon {

}

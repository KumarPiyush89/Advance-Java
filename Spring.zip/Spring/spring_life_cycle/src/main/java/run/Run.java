package run;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pojo_classes.Database;
import pojo_classes.Person;
import pojo_classes.Student;

public class Run {
	public static void main(String[] args) {
//		ApplicationContext c = new ClassPathXmlApplicationContext("config.xml");
//		Person p = (Person) c.getBean("person");
//		System.out.println(p);
		
//		((ConfigurableApplicationContext)p).close();  // spring container object is closed
//		System.out.println(p);
		
//		Student s = (Student) c.getBean("student");
//		System.out.println(s);
		
		ApplicationContext d = new ClassPathXmlApplicationContext("config.xml");
		Database d1 = (Database) d.getBean("database");
		System.out.println(d1);
		
		((ConfigurableApplicationContext)d).close(); 
		
		
	}
}

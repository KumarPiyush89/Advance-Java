package pojo_classes;

public class Person {
	public Person() {
		System.out.println("Person class constructor");
	}
}

package pojo_classes;

public class Student {
	public Student() {
		System.out.println("Student class constructor");
	}
	
}

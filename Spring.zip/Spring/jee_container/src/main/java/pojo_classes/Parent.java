package pojo_classes;

public class Parent {
	public void care() {
		System.out.println("Parent take Care");
	}
}

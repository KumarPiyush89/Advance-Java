package pojo_classes;

public class Teacher {
	public void teach() {
		System.out.println("Teacher teach Student's");
	}
}

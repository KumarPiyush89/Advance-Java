package pojo_classes;

public class Student {
	public void study() {
		System.out.println("Student is Studying");
	}
}

package pojo_classes;

import org.springframework.beans.factory.annotation.Value;

public class Student {
	
	int id;
	String name;
	double percentage;
	
	public Student(@Value(value="100") int id, @Value("Piyush") String name, @Value("88.68") double percentage) {
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	
	public void display() {
		System.out.println("Id :"+id);
		System.out.println("Name :"+name);
		System.out.println("Percentage :"+percentage);
	}
}

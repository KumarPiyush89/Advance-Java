package pojo_classes;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component(value="emp")
public class Employee {
	@Value(value="101")
	int id;
	
	@Value("Piyush")
	String name;
	
	@Value("25000")
	double salary;
	
	
	@Value("123456")
	long phone;
	
	public void display() {
		System.out.println("Id :"+id);
		System.out.println("Name :"+name);
		System.out.println("Salary :"+salary);
		System.out.println("Phone :"+phone);
	}
}

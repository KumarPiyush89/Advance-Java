package run;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pojo_classes.Amazon;
import pojo_classes.Item;

public class Run {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");

		Amazon amazon =(Amazon)context.getBean("amazon");
//		Item item =(Item)context.getBean("item");
		Map<Integer , Item> cart = amazon.getCart();
//		Map<Integer , Item> cart = item.getName();
		
		for(Map.Entry<Integer, Item> m: cart.entrySet()) {
			System.out.println(m.getKey()+" :"+m.getValue().getName()+" "+m.getValue().getPrice());
		}
		
	}
}

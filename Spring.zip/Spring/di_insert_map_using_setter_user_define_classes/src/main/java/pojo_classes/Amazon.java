package pojo_classes;

import java.util.Map;

public class Amazon {
	private Map<Integer ,Item> cart;

	public Map<Integer, Item> getCart() {
		return cart;
	}

	public void setCart(Map<Integer, Item> cart) {
		this.cart = cart;
	}

	@Override
	public String toString() {
		return "Amazon [cart=" + cart + "]";
	}

	
	
}

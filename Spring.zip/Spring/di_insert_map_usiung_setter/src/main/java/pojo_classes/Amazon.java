package pojo_classes;

import java.util.Map;

public class Amazon {
	private Map<String , Double> cart;

	public Map<String, Double> getCart() {
		return cart;
	}

	public void setCart(Map<String, Double> cart) {
		this.cart = cart;
	}
	
}

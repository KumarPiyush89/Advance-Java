package entity_classes;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Cacheable
@Entity
public class Employee {
	@Id
	 int id;
	 String name;
	 double salary;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
	
}

package merge;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity_classes.Pancard;
import entity_classes.Person;

public class Merge {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("one_to_one_bi");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Person p1 = em.find(Person.class, 3);
		Pancard pan1 = em.find(Pancard.class, 103);
		p1.setPancard(pan1);
		pan1.setPerson(p1);
		
		et.begin();
		em.merge(p1);
		em.merge(pan1);
		et.commit();
		
	}
}

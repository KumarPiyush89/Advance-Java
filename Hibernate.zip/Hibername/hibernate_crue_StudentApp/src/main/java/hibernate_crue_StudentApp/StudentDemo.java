package hibernate_crue_StudentApp;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentDemo {
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		System.out.println(emf);
	}
}

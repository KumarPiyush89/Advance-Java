package StudentApp;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;


import hibernate_crue_StudentApp.Student;



public class StudentApp {
	
	
	public static void addStudent()
	{
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		System.out.println("Enter id: -");
		int id = sc.nextInt();
		System.out.println("Enter Name: -");
		String name = sc.next();
		System.out.println("Enter Age: -");
		int age = sc.nextInt();
		System.out.println("Enter Percentage: -");
		double percentage = sc.nextDouble();
		
		
		et.begin();
		Student s1 = new Student(id,name,age,percentage);
		em.persist(s1);
		et.commit();
		System.out.println("Data Inserted Successfully");
		
	}
	
	public static  void removeStudent()
	{
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		System.out.println("Enter id: -");
		int id = sc.nextInt();
		Student s1 = em.find(Student.class, id);
		
		et.begin();
		em.remove(s1);
		et.commit();
		System.out.println("Data Delete successfully");
		
	}
	
	public static void findStudent()
	{
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		System.out.println("Enter id: -");
		int id = sc.nextInt();
		Student s1 = em.find(Student.class, id);
		System.out.println(s1);
	}
	
	
	public static void findAll() {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Query query = em.createQuery("select stu from Student stu");
		List<Student> stu = query.getResultList();
		
		for(Student s1: stu)
		{
			System.out.println(s1);
		}
	}
	
	
	public static void update() {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		System.out.println("Enter id: -");
		int id = sc.nextInt();
		Student s1 = em.find(Student.class , id);
		s1.setName("Piyush");
		s1.setAge(600000);
		et.begin();
		em.merge(s1);
		em.merge(s1);
		et.commit();
		System.out.println("Data updated Successfully");
	}
	
	public static void findpercentage() {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		System.out.println("Enter Percentage: -");
		double percentage = sc.nextDouble();
		Student s1 = em.find(Student.class, percentage);
		if(percentage >= 35)
		{
			System.out.println(s1);
		}else {
			System.out.println("Sorry!!");
		}
		
		
	}
	
	
	
	public static void main(String[] args) {
	
		
//		insert student
//		addStudent();
		
//		Remove
//		removeStudent();
		
//		find
//		findStudent();
		
//		FetchAll
//		findAll();
		
//		update
//		update();
		
//		percentageCondition
		findpercentage();
		
		
		
		
//		
	}
}




package entity_classes;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Review {
	@Id
	private int id;
	private double rating;
	private String discription;
	
	@ManyToOne
	private Product products;
	 
	
	public Review() {
		
	}


	public Review(int id, double rating, String discription, Product products) {
		super();
		this.id = id;
		this.rating = rating;
		this.discription = discription;
		this.products = products;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}


	public String getDiscription() {
		return discription;
	}


	public void setDiscription(String discription) {
		this.discription = discription;
	}


	public Product getProducts() {
		return products;
	}


	public void setProduct(Product products) {
		this.products = products;
	}


	@Override
	public String toString() {
		return "Review [id=" + id + ", rating=" + rating + ", discription=" + discription + ", products=" + products
				+ "]";
	}
		
}

package merge;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity_classes.Product;
import entity_classes.Review;

public class Merge {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("many_to_one");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		
		
		Product p1 = new Product(3,"Samsung",25000);
		
		Review r = em.find(Review.class, 1);
//		r.getProducts().add(p1);
//		r.getProducts()
		r.getProducts();
		
		et.begin();
		em.persist(p1);
		em.merge(r);
		et.commit();
	}
}

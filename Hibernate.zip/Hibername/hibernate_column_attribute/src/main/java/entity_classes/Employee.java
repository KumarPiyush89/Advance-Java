package entity_classes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	private int id;
	
	@Column(nullable = false)
	private String name;
	
	@Column(updatable = false)
	private int age;
	
	@Column(insertable = false)
	private String company_name;
	
	@Column(unique = true)
	private long phone;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String name, int age, String company_name, long phone) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.company_name = company_name;
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", company_name=" + company_name + ", phone="
				+ phone + "]";
	} 
	
	
}

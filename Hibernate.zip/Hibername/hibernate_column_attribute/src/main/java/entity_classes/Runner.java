package entity_classes;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Runner {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("attribute");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Employee emp1 = new Employee(1,"Piyush",22,"asdf",123456);
		Employee emp2 = new Employee(2,"Kumar",23,"lkjh",654987);
		
		Employee emp3 = new Employee(3,"null",23,"lkjh",654987);
		
		et.begin();
//		em.persist(emp1);
//		em.persist(emp2);
		em.persist(emp3);
		et.commit();
		
	}
}

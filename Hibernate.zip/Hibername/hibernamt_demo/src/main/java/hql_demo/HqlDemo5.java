package hql_demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import hibernamt_demo.Employee;

public class HqlDemo5 {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Query query = em.createQuery("select e from Employee e where e.id =?1 or e.id = ?2");
		query.setParameter(1, 1);
		query.setParameter(2, 2);
		List<Employee> emps = query.getResultList();
		for(Employee e : emps) {
			System.out.println(e);
		}
		
		System.out.println("=========================");
		
		Query query2 = em.createQuery("select e from Employee e where e.id = :id1 or e.id = :id2");
		query2.setParameter("id1", 1);
		query2.setParameter("id2", 2);
		List<Employee> emps2 = query2.getResultList();
		for(Employee e : emps2) {
			System.out.println(e);
		}
	}
}

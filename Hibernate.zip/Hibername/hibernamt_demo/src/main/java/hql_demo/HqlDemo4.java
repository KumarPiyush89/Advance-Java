package hql_demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import hibernamt_demo.Employee;

public class HqlDemo4 {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
//		to fetch Multiple column from the database table using hibernate Query
		
		Query query1 = em.createQuery("select e from Employee e where e.id in (1,2,3)");
		List<Employee> emps = query1.getResultList();
		for(Employee e : emps)
		{
			System.out.println(e);
		}
		
		System.out.println("=================");
		
		Query query2 = em.createQuery("select e from Employee e where e.id between 1 and 2");
		List<Employee> emps2 = query2.getResultList();
		for(Employee e : emps2)
		{
			System.out.println(e);
		}
		
		
	}
}

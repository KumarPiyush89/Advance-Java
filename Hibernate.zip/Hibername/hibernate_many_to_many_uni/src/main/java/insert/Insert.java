package insert;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity_classes.Student;
import entity_classes.Subject;

public class Insert {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("many_to_many_uni");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Subject s1 = new Subject(101,"Physics");
		Subject s2 = new Subject(102,"Chemistry");
		Subject s3 = new Subject(103,"Math");
		Subject s4 = new Subject(104,"Bio");
		
		List<Subject> subjects1 = new ArrayList<Subject>();
		subjects1.add(s1);
		subjects1.add(s2);
		subjects1.add(s4);
		Student stud1 = new Student(1,"Piyush",22,subjects1); 
		
		List<Subject> subjects2 = new ArrayList<Subject>();
		subjects2.add(s1);
		subjects2.add(s2);
		subjects2.add(s3);
		Student stud2 = new Student(2,"Kumar",22,subjects2);
		
		et.begin();
		em.persist(s1);
		em.persist(s2);
		em.persist(s3);
		em.persist(s4);
		em.persist(stud1);
		em.persist(stud2);
		
		et.commit();
		
		
		
		
	}
}

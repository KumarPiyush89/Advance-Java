package insert;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity_classes.Pancard;
import entity_classes.Person;

public class CascadeInsert {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("one_to_one_uni");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		Pancard pan1 = new Pancard(103, "Agra", "01-jan-2020");
		Pancard pan2 = new Pancard(104, "Agra", "02-dec-2021");
		
		Person p1 = new Person(5, "Alok",666, pan1);
		Person p2 = new Person(6, "Saurabh",777, pan2);
		
		et.begin();
		em.persist(p1);
		em.persist(p2);
		et.commit();
	}
}

package controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pojo_classes.Person;

@Controller
public class Control {
	
	@Autowired
	Person person;
	
@GetMapping(value = "/welcome")
	public String Welcome() {
		return "welcome.jsp";
	}

	@GetMapping("/display")
	public String display(Model model) {
		
		model.addAttribute("message","Welcome to the display page");
		model.addAttribute("person" , person);
		return "display.jsp";
	}
	
	@PostMapping("/employee")
	public String getEmployee(HttpServletRequest req , Model model) {
		String name = req.getParameter("name");
		String age = req.getParameter("age");
		String salary = req.getParameter("salary");
//		double salary = Double.parseDouble(req.getParameter("salary"));
		
		model.addAttribute("Name ",name);
		model.addAttribute("Age ",age);
		model.addAttribute("Salary ",salary);
		
//		return "emp_diaplay.jsp";
		return "emp2.jsp";
		
	}
	
	
	@PostMapping("/cal_perc")
	public void calcPercentage(HttpServletRequest req ,HttpServletResponse resp) throws ServletException, IOException {
		double physics = Double.parseDouble(req.getParameter("physic"));
		double math = Double.parseDouble(req.getParameter("math"));
		double chemistry = Double.parseDouble(req.getParameter("chemistry"));
		
		double percentage = (((physics+math+chemistry)/300)*100);
		
		req.setAttribute("percentage", percentage);
		
		RequestDispatcher rd = req.getRequestDispatcher("display_perc");
		rd.forward(req, resp);
		
	}
		
	@PostMapping("/display_perc")
	public String displayPercentage(HttpServletRequest req, Model model) {
		
		String name = req.getParameter("name");
		Double percentage =(Double)req.getAttribute("percentage");
		model.addAttribute("name" , name);
		model.addAttribute("percentage",percentage);
		
			
		
		
		if(percentage > 35) {
			model.addAttribute("result", "Passed");
		}
		else {
			model.addAttribute("result", "failed");
		}
		
		return "display_perc.jsp";
	}
	
	
	
//	----------------------------------
//	include
	
	@PostMapping("/validate")
	public void  validate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		
		RequestDispatcher rd = req.getRequestDispatcher("validate.jsp");
		
		if(name.equals("Admin") && password.equals("admin123")) {
			req.setAttribute("Status", "Success");
			rd.include(req, resp);
		} else {
			req.setAttribute("Status", "Failed");
			rd.include(req, resp);
		}
				
	}
	
//	------------------------
//	Servlet Context
	
	@GetMapping("/contextA")
	public String contextA(HttpServletRequest req , Model model) {
		
		ServletContext context = req.getServletContext();
		String name =context.getInitParameter("name");
		
		context.setAttribute("age", 35 );
		context.setAttribute("team", "Mumbai Indains");
		model.addAttribute("name",name);
		
		return "context1.jsp";
	}
	
	
	@GetMapping("/contextB")
	public String contextB(HttpServletRequest req , Model model) {
		ServletContext context = req.getServletContext();
		model.addAttribute("name",context.getInitParameter("name"));
		model.addAttribute("age",(Integer)context.getAttribute("age"));
		model.addAttribute("team",(String)context.getAttribute("team"));
		
		return "context2.jsp";
	}
	
//	---------------------------
//	Cookie
	
	@PostMapping("/cookie1")
	public String cookie1(HttpServletRequest req , HttpServletResponse resp) {
		String jno = req.getParameter("jno");
		String name = req.getParameter("name");
		String age = req.getParameter("age");
		String team = req.getParameter("team");
		
		Cookie cookie_jno = new Cookie("jno" , jno);
		Cookie cookie_name = new Cookie("name",name);
		Cookie cookie_age = new Cookie("age",age);
		Cookie cookie_team = new Cookie("team",team);
		
		resp.addCookie(cookie_jno);
		resp.addCookie(cookie_name);
		resp.addCookie(cookie_age);
		resp.addCookie(cookie_team);
		return "cookie2.jsp";
	}
	
	@GetMapping("/cookie3")	
	public String cookie3() {
		
		return "cookie3.jsp";
	}
	
	
	
}

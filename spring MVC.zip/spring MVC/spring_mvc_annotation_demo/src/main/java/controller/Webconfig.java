package controller;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "controller")
public class Webconfig {

}
